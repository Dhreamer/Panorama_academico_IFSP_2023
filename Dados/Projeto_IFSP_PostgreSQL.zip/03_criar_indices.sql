-- Projeto IFSP | PNP 2024, ano-base 2023
-- Execute no banco pnp_ifsp_2023. Os arquivos CSV originais não são alterados.

-- Acelera o recorte por instituição/ano e a escolha de unidade no IFSP.
-- Execute DEPOIS da importação; criar o índice antes torna a carga mais lenta.
CREATE INDEX IF NOT EXISTS ix_matriculas_inst_ano_unidade
ON pnp_raw.matriculas_2023 (co_inst, ano, cod_unidade);

CREATE INDEX IF NOT EXISTS ix_eficiencia_inst_ano_unidade
ON pnp_raw.eficiencia_2023 (co_inst, ano, cod_unidade);

ANALYZE pnp_raw.matriculas_2023;
ANALYZE pnp_raw.eficiencia_2023;
