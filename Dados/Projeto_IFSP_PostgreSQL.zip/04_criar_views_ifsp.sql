-- Projeto IFSP | PNP 2024, ano-base 2023
-- Execute no banco pnp_ifsp_2023. Os arquivos CSV originais não são alterados.

-- Views são consultas salvas. Não mudam as tabelas pnp_raw.
-- A unidade de cada linha continua sendo uma MATRÍCULA, não uma pessoa.
-- Inscritos e vagas aparecem repetidos por matrícula; NÃO some essas colunas aqui.
CREATE OR REPLACE VIEW pnp.matriculas_ifsp_2023 AS
SELECT
    r.*,
    NULLIF(BTRIM(r.idade), '')::integer AS idade_num,
    NULLIF(BTRIM(r.carga_horaria), '')::integer AS carga_horaria_num,
    REPLACE(NULLIF(BTRIM(r.fator_esforco_curso), ''), ',', '.')::numeric
        AS fator_esforco_num,
    NULLIF(BTRIM(r.total_de_inscritos), '')::integer AS total_inscritos_repetido_no_ciclo,
    d.inicio AS inicio_ciclo_data,
    d.fim AS fim_previsto_ciclo_data,
    d.fim - d.inicio AS duracao_prevista_dias,
    CASE
        WHEN d.inicio IS NULL OR d.fim IS NULL OR d.fim < d.inicio THEN 'Sem duração válida'
        WHEN d.fim - d.inicio <= 183 THEN 'Até 6 meses'
        WHEN d.fim - d.inicio <= 731 THEN 'Mais de 6 até 24 meses'
        ELSE 'Mais de 24 meses'
    END AS faixa_duracao_planejada,
    NULLIF(BTRIM(r.categoria_da_situacao), '') AS categoria_situacao_limpa,
    NULLIF(BTRIM(r.situacao_de_matricula), '') AS situacao_matricula_limpa
FROM pnp_raw.matriculas_2023 r
CROSS JOIN LATERAL (
    SELECT TO_DATE(NULLIF(BTRIM(r.data_de_inicio_do_ciclo), ''), 'DD/MM/YYYY') AS inicio,
           TO_DATE(NULLIF(BTRIM(r.data_de_fim_previsto_do_ciclo), ''), 'DD/MM/YYYY') AS fim
) d
WHERE r.co_inst = '26439' AND r.ano = '2023';

CREATE OR REPLACE VIEW pnp.eficiencia_ifsp_2023 AS
SELECT
    r.*,
    NULLIF(BTRIM(r.idade), '')::integer AS idade_num,
    NULLIF(BTRIM(r.carga_horaria), '')::integer AS carga_horaria_num,
    REPLACE(NULLIF(BTRIM(r.fator_esforco_curso), ''), ',', '.')::numeric
        AS fator_esforco_num,
    d.inicio AS inicio_ciclo_data,
    d.fim AS fim_previsto_ciclo_data,
    d.fim - d.inicio AS duracao_prevista_dias,
    CASE
        WHEN d.inicio IS NULL OR d.fim IS NULL OR d.fim < d.inicio THEN 'Sem duração válida'
        WHEN d.fim - d.inicio <= 183 THEN 'Até 6 meses'
        WHEN d.fim - d.inicio <= 731 THEN 'Mais de 6 até 24 meses'
        ELSE 'Mais de 24 meses'
    END AS faixa_duracao_planejada,
    NULLIF(BTRIM(r.categoria_da_situacao), '') AS categoria_situacao_limpa,
    NULLIF(BTRIM(r.situacao_de_matricula), '') AS situacao_matricula_limpa
FROM pnp_raw.eficiencia_2023 r
CROSS JOIN LATERAL (
    SELECT TO_DATE(NULLIF(BTRIM(r.data_de_inicio_do_ciclo), ''), 'DD/MM/YYYY') AS inicio,
           TO_DATE(NULLIF(BTRIM(r.data_de_fim_previsto_do_ciclo), ''), 'DD/MM/YYYY') AS fim
) d
WHERE r.co_inst = '26439' AND r.ano = '2023';
