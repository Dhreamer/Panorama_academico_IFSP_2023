-- Execute com o programa psql, uma única vez, após criar as tabelas.
-- EDITE os dois caminhos abaixo para apontar aos CSVs EXTRAÍDOS no seu computador.
-- Use barras normais / mesmo no Windows. Exemplo: C:/Dados/PNP/arquivo.csv
-- Não execute no Query Tool do pgAdmin: \copy é comando do psql.
-- O cabeçalho é pulado; o vínculo com as colunas é pela ORDEM, não pelo nome.
\copy pnp_raw.matriculas_2023 FROM 'C:/DADOS_PNP/microdados_matriculas_2023.csv' WITH (FORMAT csv, HEADER true, DELIMITER ';', QUOTE '"', ENCODING 'UTF8')
\copy pnp_raw.eficiencia_2023 FROM 'C:/DADOS_PNP/microdados_eficiencia_academica_2023.csv' WITH (FORMAT csv, HEADER true, DELIMITER ';', QUOTE '"', ENCODING 'UTF8')
