-- Projeto IFSP | PNP 2024, ano-base 2023
-- Execute no banco pnp_ifsp_2023. Os arquivos CSV originais não são alterados.

-- Resultado esperado para a edição completa: 1.681.514 e 801.029.
SELECT 'matriculas_2023' AS arquivo, COUNT(*) AS linhas
FROM pnp_raw.matriculas_2023
UNION ALL
SELECT 'eficiencia_2023', COUNT(*)
FROM pnp_raw.eficiencia_2023;

-- Resultado esperado para o IFSP, código 26439: 77.558 e 41.703.
SELECT 'matriculas_2023' AS arquivo,
       COUNT(*) AS linhas_ifsp,
       COUNT(DISTINCT codigo_da_matricula) AS codigos_matricula,
       COUNT(DISTINCT cod_unidade) AS unidades
FROM pnp_raw.matriculas_2023
WHERE TRIM(co_inst) = '26439' AND TRIM(ano) = '2023'
UNION ALL
SELECT 'eficiencia_2023',
       COUNT(*), COUNT(DISTINCT codigo_da_matricula), COUNT(DISTINCT cod_unidade)
FROM pnp_raw.eficiencia_2023
WHERE TRIM(co_inst) = '26439' AND TRIM(ano) = '2023';

-- Detecta eventuais IDs repetidos DENTRO de cada arquivo no IFSP.
-- Resultado esperado: zero linhas nas duas consultas.
SELECT codigo_da_matricula, COUNT(*) AS vezes
FROM pnp_raw.matriculas_2023
WHERE co_inst = '26439' AND ano = '2023'
GROUP BY codigo_da_matricula HAVING COUNT(*) > 1 LIMIT 20;

SELECT codigo_da_matricula, COUNT(*) AS vezes
FROM pnp_raw.eficiencia_2023
WHERE co_inst = '26439' AND ano = '2023'
GROUP BY codigo_da_matricula HAVING COUNT(*) > 1 LIMIT 20;

-- Matrícula Atendida tem sentidos diferentes nos dois arquivos.
SELECT 'matriculas_2023' AS arquivo, matricula_atendida, COUNT(*) AS linhas
FROM pnp_raw.matriculas_2023 WHERE co_inst = '26439'
GROUP BY matricula_atendida
UNION ALL
SELECT 'eficiencia_2023', matricula_atendida, COUNT(*)
FROM pnp_raw.eficiencia_2023 WHERE co_inst = '26439'
GROUP BY matricula_atendida
ORDER BY arquivo, matricula_atendida;

-- Não apaga nem substitui vagas negativas. Localiza o problema na origem.
SELECT campo, valor, COUNT(*) AS linhas_afetadas
FROM pnp_raw.matriculas_2023 r
CROSS JOIN LATERAL (VALUES
    ('vagas_regulares_l13', r.vagas_regulares_l13),
    ('vagas_regulares_l14', r.vagas_regulares_l14),
    ('vagas_regulares_l2', r.vagas_regulares_l2),
    ('vagas_regulares_l5', r.vagas_regulares_l5)
) AS v(campo, valor)
WHERE r.co_inst = '26439' AND TRIM(valor) ~ '^-[0-9]+$'
GROUP BY campo, valor ORDER BY campo, valor;
