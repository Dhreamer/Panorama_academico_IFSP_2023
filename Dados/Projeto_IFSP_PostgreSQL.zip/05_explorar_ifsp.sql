-- Projeto IFSP | PNP 2024, ano-base 2023
-- Execute no banco pnp_ifsp_2023. Os arquivos CSV originais não são alterados.

-- Ver dados individuais, mantendo acesso às colunas originais.
SELECT * FROM pnp.matriculas_ifsp_2023 LIMIT 10;
SELECT * FROM pnp.eficiencia_ifsp_2023 LIMIT 10;

-- Todos os campi/unidades disponíveis no recorte anual.
SELECT cod_unidade, unidade_de_ensino, COUNT(*) AS matriculas_atendidas
FROM pnp.matriculas_ifsp_2023
GROUP BY cod_unidade, unidade_de_ensino
ORDER BY unidade_de_ensino;

-- Não misturar estes quatro totais com inscritos ou ingressantes.
SELECT categoria_situacao_limpa, situacao_matricula_limpa,
       COUNT(*) AS matriculas, ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS percentual_da_base_anual
FROM pnp.matriculas_ifsp_2023
GROUP BY categoria_situacao_limpa, situacao_matricula_limpa
ORDER BY matriculas DESC;

-- A faixa de duração é uma classificação do projeto, não do MEC.
SELECT faixa_duracao_planejada, COUNT(*) AS matriculas
FROM pnp.matriculas_ifsp_2023
GROUP BY faixa_duracao_planejada ORDER BY matriculas DESC;
